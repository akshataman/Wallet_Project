package com.cg.service;
import java.sql.SQLException;

import com.cg.jpa.entity.Account;
import com.cg.exception.InsuffecientFundException;

public interface Transaction extends AccountOperation{
	
	public boolean withdraw(Long mb,double amount) throws InsuffecientFundException, SQLException;
	
	public boolean deposite(Long mb,double amount) throws SQLException;
	
	public boolean TransferMoney(Long from, Long to,double amount) throws InsuffecientFundException, SQLException; 
	
	public default void printStatement(Account ob)
	{
		System.out.println("========================");
		System.out.println("Statement for Account No:- " + ob.getEmployee_Id());
		System.out.println("Account holder name:- " + ob.getAccount_Holder());
		System.out.println("Mobile no:- " + ob.getMobile_No());
		System.out.println("Balance is:- " + ob.getAccount_Balance());
		System.out.println("========================");
	}

}
