package com.cg.dao;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.jpa.entity.Account;

import com.cg.service.*;
import com.cg.exception.InsuffecientFundException;

import javax.persistence.*;

public class AccountDAOImpl implements AccountDAO{
	
	
	static ConcurrentHashMap<Long, Account> accamp=new ConcurrentHashMap<Long,Account>();
	
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
	
	EntityManager em=emf.createEntityManager();
	@Override
	public boolean addAccount(Account ob) throws SQLException {
		// TODO Auto-generated method stub
		accamp.put(ob.getMobile_No(), ob);
		int id=ob.getEmployee_Id();
		Long mb=ob.getMobile_No();
		String ah=ob.getAccount_Holder();
		double bal=ob.getAccount_Balance();

		em.getTransaction().begin();
		Account s1=new Account();
		s1.setEmployee_Id(id);
		s1.setMobile_No(mb);
		s1.setAccount_Holder(ah);
		s1.setAccount_Balance(bal);
		em.persist(s1);
		em.flush();
		System.out.println("Record added:-"+s1.getEmployee_Id()+s1.getMobile_No()+s1.getAccount_Holder()+s1.getAccount_Balance());
		em.getTransaction().commit();
				
		return true;
		
	}

	@Override
	public boolean updateAccount(Long mb,double amount) throws SQLException {
		// TODO Auto-generated method stub
		//accamp.put(ob.getMobile(), ob);
		Account s2=em.find(Account.class, mb);
		
		em.getTransaction().begin();
		//Student s1=new Student();
		s2.setAccount_Balance(amount);
		em.merge(s2);
		//em.flush();
		System.out.println("Record updated:-"+s2.getMobile_No());
		em.getTransaction().commit();
		
		
		return true;
	}

	@Override
	public boolean deleteAccount(Long mb) throws SQLException {
		//accamp.remove(ob);
		
		Account s4=em.find(Account.class,mb);
		s4.getMobile_No();
		em.getTransaction().begin();
		em.remove(s4);
		System.out.println("Record Deleted......");
		em.getTransaction().commit();
		
		
		
		
		return true;
	}

	@Override
	public Account findAccount(Long mb) throws SQLException {
		// TODO Auto-generated method stub
		Account s4=em.find(Account.class,mb);
			s4.getEmployee_Id();
			s4.getMobile_No();
			s4.getAccount_Holder();
			s4.getAccount_Balance();
		return  s4;
	}

	
	@Override
	public ConcurrentHashMap<Long, Account> getAllAccount() throws SQLException {
		// TODO Auto-generated method stub
		
		
		return accamp;
	}

	@Override
	public boolean TransferMoney(Long from, Long to, double amount) throws InsuffecientFundException, SQLException {
		// TODO Auto-generated method stub
		
		Account s1=em.find(Account.class,from);
		double bal=s1.getAccount_Balance()-amount;
		updateAccount(from,bal);
		
		Account s2=em.find(Account.class,to);
		 bal=s2.getAccount_Balance()+amount;
		
		updateAccount(to,bal);
		
		return true;
	}

	
}
