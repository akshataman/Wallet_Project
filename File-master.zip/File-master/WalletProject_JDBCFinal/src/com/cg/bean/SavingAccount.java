package com.cg.bean;

public class SavingAccount extends Account{
	
	private double interest;
	private final double Min_balance=1000.00;
	
	public SavingAccount() {
		// TODO Auto-generated constructor stub
	}

	public SavingAccount(int id, int mobileno, String accholdername, double balance) {
		super(id, mobileno, accholdername, balance);
		// TODO Auto-generated constructor stub
	}

	public double getInterest() {
		return interest;
	}

	public void setIntrest(double interest) {
		this.interest = super.getBalance()*0.04;
	}

	@Override
	public String toString() {
		return super.toString()+ "SavingAccount [interest=" + interest + "]";
	}

	
	
	
	
	
	

}
