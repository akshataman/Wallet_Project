package com.cg.bean;

public class Account implements Comparable<Account> {
	
	private int id;
	private long mobileno;
	private String accholdername;
	private double balance;
	
	public Account() {
		
	}

	public Account(int id, long mobileno, String accholdername, double balance) {
		super();
		this.id = id;
		this.mobileno = mobileno;
		this.accholdername = accholdername;
		this.balance = balance;
	}

	public int getId() {
		return id;
	}

	public void setId(int aid) {
		this.id = id;
	}

	public long getMobileno() {
		return mobileno;
	}

	public void setMobile(long mobileno) {
		this.mobileno = mobileno;
	}

	public String getAccholdername() {
		return accholdername;
	}

	public void setAccholdername(String accholdername) {
		this.accholdername = accholdername;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", mobileno=" + mobileno + ", accholdername=" + accholdername + ", balance="
				+ balance + "]";
	}

	@Override
	public int compareTo(Account arg0) { //default sorting based on account no
		// TODO Auto-generated method stub
		int diff=this.getId()-arg0.getId();
		if(diff>0)
			return 1;
		else if(diff<0)
			return -1;
		else
		return 0;
	}
	
	
	
	

}
